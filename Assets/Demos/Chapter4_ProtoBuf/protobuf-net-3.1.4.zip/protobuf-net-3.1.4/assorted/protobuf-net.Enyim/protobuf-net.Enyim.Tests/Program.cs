﻿using System;
using System.Collections.Generic;
using System.Text;

namespace protobuf_net.Enyim.Tests
{
    class Program
    {
        static void Main()
        {
        }
    }
}
